# LibriFox
LibriFox is a port of the LibriVox app for FirefoxOS. More information will come soon.